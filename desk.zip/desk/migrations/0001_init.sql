-- One row per user: day plan, threads, tabs, settings. Optimistic concurrency via version.
CREATE TABLE workspace (
  user_email TEXT PRIMARY KEY,
  json       TEXT NOT NULL,
  version    INTEGER NOT NULL DEFAULT 1,
  updated_at INTEGER NOT NULL
);

-- Per-tab inputs/outputs.
CREATE TABLE tab_state (
  user_email TEXT NOT NULL,
  tab_id     TEXT NOT NULL,
  json       TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (user_email, tab_id)
);

-- Daily quotas (AI generations, Lusha credits).
CREATE TABLE usage (
  user_email TEXT NOT NULL,
  day        TEXT NOT NULL,          -- YYYY-MM-DD UTC
  kind       TEXT NOT NULL,          -- 'ai' | 'lusha'
  count      INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_email, day, kind)
);

-- Every Lusha result is kept: feeds the Motherboard and avoids paying twice.
CREATE TABLE lusha_lookup (
  id             TEXT PRIMARY KEY,
  user_email     TEXT NOT NULL,
  query_key      TEXT NOT NULL,      -- normalised query, cache key
  query_json     TEXT NOT NULL,
  response_json  TEXT,
  credit_charged INTEGER NOT NULL DEFAULT 0,
  status         INTEGER NOT NULL,   -- upstream HTTP status
  created_at     INTEGER NOT NULL
);
CREATE INDEX idx_lusha_user_key ON lusha_lookup (user_email, query_key, created_at);
CREATE INDEX idx_lusha_user_time ON lusha_lookup (user_email, created_at);

-- Append-only audit trail of writes and paid calls.
CREATE TABLE audit (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_email TEXT NOT NULL,
  action     TEXT NOT NULL,
  detail     TEXT,
  at         INTEGER NOT NULL
);
CREATE INDEX idx_audit_user_time ON audit (user_email, at);
