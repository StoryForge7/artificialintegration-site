"use strict";
/* ============ API client ============ */
class ApiError extends Error{constructor(status,code,message,extra){super(message);this.status=status;this.code=code;this.extra=extra||{}}}
async function api(method,path,body){
  let res;
  try{
    res=await fetch(path,{method,credentials:"same-origin",headers:{"X-Desk":"1",...(body!==undefined?{"Content-Type":"application/json"}:{})},body:body!==undefined?JSON.stringify(body):undefined});
  }catch{throw new ApiError(0,"offline","No connection. Changes will retry.")}
  // Access redirects an expired session to its login page (opaque HTML)
  const ct=res.headers.get("content-type")||"";
  if(!ct.includes("application/json")){
    if(res.status===401||res.status===403||res.redirected)throw new ApiError(401,"unauthenticated","Session expired. Reload to sign in.");
    throw new ApiError(res.status,"bad_response","Unexpected server response ("+res.status+").");
  }
  const data=await res.json();
  if(!res.ok){const e=data.error||{};throw new ApiError(res.status,e.code||"error",e.message||"Request failed.",e)}
  return data;
}
function showBanner(msg){const b=document.getElementById("banner");if(!msg){b.hidden=true;return}b.textContent=msg;b.hidden=false}

/* ============ Definitions ============ */
const LANES=[
  {id:"morning",name:"Morning calls",hint:"Candidates, referrals, client catch-ups"},
  {id:"midday",name:"Midday sourcing",hint:"Searches, strings, outreach"},
  {id:"afternoon",name:"Afternoon BD",hint:"Mapping, hitlists, spec calls"},
  {id:"wrap",name:"Wrap-up",hint:"CVs out, notes in, tomorrow’s list"},
  {id:"waiting",name:"Waiting on",hint:"Parked until something lands"}
];
const KINDS={
  candidate:{label:"Place a candidate",blurb:"Someone’s looking. Spec them, format the CV, find where to send it.",color:"--cand",tools:["cvspecs","cvformat","specemail","mapping","lusha"]},
  job:{label:"Fill a job",blurb:"A vacancy’s live. Build strings, write outreach, map who to attack.",color:"--job",tools:["strings","composer","mapping","lusha"]},
  bd:{label:"Find vacancies",blurb:"Fishing for jobs. Adverts, mapping and a hitlist to call.",color:"--bd",tools:["adverts","mapping","bdmanager"]}
};
const CTX_FIELDS=[["role","Role / candidate"],["level","Level"],["location","Location"],["salary","Salary"],["notice","Notice"],["notes","Notes"]];
const S=(s)=>String(s??"");
const lines=(s)=>S(s).split("\n").map(x=>x.trim()).filter(Boolean);

const ai=async(prompt)=>(await api("POST","/api/ai",{prompt})).text;
const aiJson=async(prompt)=>(await api("POST","/api/ai",{prompt,json:true})).data;

const TOOLS={
  cvspecs:{name:"CV specs",desc:"Paste the CV. Get the client-ready spec: heading, bullets, then location, salary and notice.",
    fields:[{k:"cv",label:"CV text",area:true,big:true,req:true}],
    run:(i,c,st)=>ai(`Write a candidate spec for a client email.
Format exactly:
"<Candidate Name> – <Job Title>" on line one,
then 5–8 concise bullet points ("• ") on experience, project types and values, sectors, key skills,
then three lines: "Location: …", "Salary: …", "Notice: …".
Use only facts in the CV or context; write "TBC" if unknown.
House rules:\n${st.houseRules}\nContext:\n${ctxText(c)}\nCV:\n${i.cv}`)},
  cvformat:{name:"CV format",desc:"Restructure a CV into your house order. Branded PDF export comes in a later build.",
    fields:[{k:"cv",label:"Original CV text",area:true,big:true,req:true},{k:"order",label:"Header order",val:"Position, Salary, Location, Notice"}],
    run:(i,c)=>ai(`Restructure this CV into a clean recruitment-agency format as plain text.
Header block in this order: ${i.order}. Then "Profile" (3–4 lines), "Key skills" (bullets), "Employment history" (most recent first: Company, Title, Dates, then bullets with projects and values), "Education & qualifications".
Remove the candidate’s personal phone, email and home address. Put "[Agency logo]" as the first line.
Context:\n${ctxText(c)}\nCV:\n${i.cv}`)},
  lusha:{name:"Lusha",desc:"Contact lookup. Give a LinkedIn URL, an email, or first + last name with company. Results are cached 30 days and logged to the Motherboard.",
    fields:[{k:"linkedinUrl",label:"LinkedIn URL"},{k:"email",label:"Email"},{k:"firstName",label:"First name"},{k:"lastName",label:"Last name"},{k:"companyName",label:"Company name"},{k:"companyDomain",label:"Company domain"}],
    validate:(i)=>(i.linkedinUrl||i.email||(i.firstName&&i.lastName&&(i.companyName||i.companyDomain)))?null:"Give a LinkedIn URL, an email, or first + last name with a company.",
    run:async(i)=>{
      const r=await api("POST","/api/lusha/person",i);
      if(!r.result)return "No match in Lusha.";
      const d=r.result?.contact?.data;
      return (r.cached?"From cache ("+new Date(r.at).toLocaleDateString("en-GB")+"), no credit used.\n\n":"")+formatContact(d);
    },needs:"lusha"},
  strings:{name:"Company strings",desc:"Competitor companies turned into LinkedIn Recruiter company strings, split to your character limit.",
    fields:[{k:"target",label:"Company type to target",area:true,req:true},{k:"seed",label:"Companies you already know (one per line)",area:true},{k:"limit",label:"Max characters per string",num:true}],
    run:async(i,c,st)=>{
      const lim=Math.min(10000,Math.max(200,parseInt(i.limit||st.stringLimit,10)||1000));
      const r=await aiJson(`List UK companies that are realistic competitors or peers for sourcing candidates.
Target: ${i.target}\nContext:\n${ctxText(c)}
Include these known names: ${lines(i.seed).join("; ")||"none"}
Return {"companies":["Name", ...]} with 25–60 distinct trading names as they appear on LinkedIn.`);
      const got=Array.isArray(r?.companies)?r.companies:[];
      const names=[...new Set([...lines(i.seed),...got.map(x=>S(x).trim())].filter(Boolean))];
      return buildStrings(names,lim);
    }},
  composer:{name:"Message composer",desc:"Recruiter InMail in your style: subject, hook, project, why them, package, call to action. Plus a short follow-up.",
    fields:[{k:"job",label:"Job details",area:true,req:true},{k:"who",label:"Who you’re writing to (optional)",area:true}],
    run:(i,c,st)=>ai(`Write a LinkedIn Recruiter InMail.
Structure: Subject line (role, value, location, salary, perks) / discreet hook / project paragraph / why the client stands out / package as bullets / call to action / signature "${st.name||"[Name]"}".
Then a 2–3 line follow-up and a connection-request version under 280 characters.
Keep the client anonymous unless the job details name them for publication.
Match this consultant’s style:\n${st.styleSamples||"(no samples yet: conversational, no hard sell)"}
House rules:\n${st.houseRules}\nContext:\n${ctxText(c)}\nJob:\n${i.job}\nRecipient:\n${i.who||"unknown"}`)},
  adverts:{name:"Adverts",desc:"Job-board advert plus the short LinkedIn post that goes with it.",
    fields:[{k:"job",label:"Vacancy details",area:true,req:true},{k:"anon",label:"Client name in advert?",sel:["Keep anonymous","Name the client"]}],
    run:(i,c,st)=>ai(`Write (1) a full job-board advert built to drive applications: title line, 2-line hook, the role, the company (${i.anon}), what you’ll need, package, how to apply; and (2) a LinkedIn post under 1,000 characters for the same role.
House rules:\n${st.houseRules}\nContext:\n${ctxText(c)}\nVacancy:\n${i.job}`)},
  mapping:{name:"Company mapping",desc:"Map companies and the decision-makers or candidates to target. Look people up in the Lusha tab.",
    fields:[{k:"brief",label:"What you’re mapping",area:true,req:true},{k:"region",label:"Region",ctx:"location"}],
    run:(i,c)=>ai(`Produce a company map for a UK recruitment consultant.
Group by tier (Tier 1, Tier 2, regional/boutique). For each: company, why it fits, which job titles to target (decision-makers for BD, or candidate titles for headhunting).
No named people or contact details. Mark anything uncertain "verify".
Region: ${i.region||"from context"}\nContext:\n${ctxText(c)}\nBrief:\n${i.brief}`)},
  specemail:{name:"Spec email contacts",desc:"Paste your contact list. Get it grouped by niche and location, with who to spec this candidate to.",
    fields:[{k:"list",label:"Contacts (paste rows: name, email, company, sector, location)",area:true,big:true,req:true},{k:"exclude",label:"Never include (one per line)",area:true}],
    run:(i,c)=>ai(`Group these contacts by niche (e.g. Fit-out, Main contracting, Developer, High-end resi, M&E, Data centre) and London vs non-London.
Then list the best-fit send list for the candidate in context, with a one-line reason each.
Use ONLY contacts in the list; never alter emails. Exclude: ${lines(i.exclude).join("; ")||"none"}.
Context:\n${ctxText(c)}\nContacts:\n${i.list}`)},
  bdmanager:{name:"BD manager",desc:"Give it a candidate or a niche. Get a hitlist to call through, each with a reason.",
    fields:[{k:"angle",label:"Candidate or niche to break into",area:true,req:true},{k:"mode",label:"Mode",sel:["Candidate-led (market a person)","Fishing for new jobs"]}],
    run:(i,c)=>ai(`Build a BD call hitlist for a UK recruitment consultant. Mode: ${i.mode}.
Output 15–25 rows as: Company — target title — reason to call (live project, growth, likely gap, market-a-candidate angle) — opener line.
Then 3 referral or market-intel calls worth making and what to ask.
No named people or contact details; look them up in Lusha. Mark uncertain facts "verify".
Context:\n${ctxText(c)}\nAngle:\n${i.angle}`)},
};
function formatContact(d){
  if(!d)return "No data returned.";
  const out=[];
  const name=d.fullName||[d.firstName,d.lastName].filter(Boolean).join(" ");
  if(name)out.push(name);
  const title=d.jobTitle?.title||d.jobTitle||d.currentJobTitle;
  const comp=d.company?.name||d.companyName;
  if(title||comp)out.push([typeof title==="string"?title:"",comp].filter(Boolean).join(" at "));
  const emails=(d.emailAddresses||d.emails||[]).map(e=>e.email||e).filter(Boolean);
  const phones=(d.phoneNumbers||d.phones||[]).map(p=>(p.number||p)+(p.phoneType?" ("+p.phoneType+")":"")).filter(Boolean);
  if(emails.length)out.push("Email: "+emails.join(", "));
  if(phones.length)out.push("Phone: "+phones.join(", "));
  const li=d.socialLinks?.linkedin||d.linkedinUrl;if(li)out.push("LinkedIn: "+li);
  if(!emails.length&&!phones.length)out.push("No email or phone returned.");
  return out.join("\n");
}

/* ============ State ============ */
const DEFAULT_WS=()=>({v:1,
  settings:{name:"",houseRules:"Say “procurement” of packages, never “buying”.\nInMails always have a subject line.\nReferences are about the candidate only.",styleSamples:"",stringLimit:1000},
  tasks:[],threads:[],tabs:[],active:"home"});
let ws=DEFAULT_WS(),wsVersion=0,me={email:"",ai:false,lusha:false};
const tabData=new Map();
const uid=()=>crypto.randomUUID().replace(/-/g,"").slice(0,20); // matches server TAB_ID pattern
const say=(m)=>{document.getElementById("live").textContent=m};
function esc(s){return S(s).replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]))}
function threadOf(id){return ws.threads.find(t=>t.id===id)}
function ctxText(t){if(!t)return"(none)";return CTX_FIELDS.map(([k,l])=>`${l}: ${S(t.ctx[k])||"—"}`).join("\n")}
function gColor(kind){return `var(${(KINDS[kind]||{color:"--sys"}).color})`}

/* Saving: debounced, serialised (one in flight), retried, conflict-aware */
let wsDirty=false,wsSaving=false,wsTimer=null,retryMs=2000;
function saveWs(){wsDirty=true;clearTimeout(wsTimer);wsTimer=setTimeout(flushWs,600)}
async function flushWs(){
  if(wsSaving||!wsDirty)return;
  wsSaving=true;wsDirty=false;
  try{
    const r=await api("PUT","/api/workspace",{version:wsVersion,data:ws});
    wsVersion=r.version;retryMs=2000;showBanner(null);
  }catch(e){
    if(e.code==="conflict"&&e.extra.current){
      ws=sanitize(e.extra.current.data);wsVersion=e.extra.current.version;tabData.clear();
      showBanner("Updated from another device. Your last change wasn’t saved, so redo it if needed.");render();
    }else if(e.code==="unauthenticated"){showBanner(e.message);wsDirty=true}
    else{wsDirty=true;showBanner("Not saved: "+e.message+" Retrying.");setTimeout(flushWs,retryMs);retryMs=Math.min(retryMs*2,60000)}
  }finally{wsSaving=false;if(wsDirty)saveWs()}
}
addEventListener("beforeunload",(e)=>{if(wsDirty||wsSaving){e.preventDefault();e.returnValue=""}});
const tabTimers={};
function saveTab(id){clearTimeout(tabTimers[id]);tabTimers[id]=setTimeout(async()=>{
  const d=tabData.get(id);if(!d)return;
  if(d.output&&d.output.length>60000)d.output=d.output.slice(0,60000);
  try{await api("PUT","/api/tabs/"+id,d)}catch(e){console.error("save tab",e);showBanner("Tab not saved: "+e.message)}
},700)}

function buildStrings(names,limit){
  const out=[];let cur="";
  for(const n of names){
    const q='"'+n.replace(/"/g,"")+'"';
    const next=cur?cur+" OR "+q:q;
    if(next.length>limit&&cur){out.push(cur);cur=q}else cur=next;
  }
  if(cur)out.push(cur);
  return out.map((s,i)=>`String ${i+1} of ${out.length} (${s.length} chars)\n${s}`).join("\n\n")+`\n\n${names.length} companies. Check names against LinkedIn before saving searches.`;
}

/* ============ Tabs ============ */
function openTool(tool,threadId=null,focus=true){
  const t={id:uid(),tool,threadId};
  if(threadId){const last=ws.tabs.map(x=>x.threadId).lastIndexOf(threadId);ws.tabs.splice(last+1,0,t)}else ws.tabs.push(t);
  if(focus)ws.active=t.id;saveWs();return t;
}
function startWorkflow(kind,title,ctx){
  const th={id:uid(),kind,title:title||KINDS[kind].label,ctx,collapsed:false,created:Date.now()};
  ws.threads.push(th);let first=null;
  for(const tool of KINDS[kind].tools){const t=openTool(tool,th.id,false);first=first||t}
  ws.active=first.id;saveWs();render();
}
function dropTab(id){tabData.delete(id);api("DELETE","/api/tabs/"+id).catch(e=>console.error("drop tab",e))}
function closeTab(id){
  const i=ws.tabs.findIndex(t=>t.id===id);if(i<0)return;
  ws.tabs.splice(i,1);dropTab(id);
  if(ws.active===id)ws.active=(ws.tabs[i]||ws.tabs[i-1]||{id:"home"}).id;
  saveWs();render();
}
function closeThread(thId){
  const th=threadOf(thId);if(!th)return;
  if(!confirm(`Close “${th.title}” and its tabs? Linked tasks stay on Home.`))return;
  ws.tabs.filter(t=>t.threadId===thId).forEach(t=>dropTab(t.id));
  ws.tabs=ws.tabs.filter(t=>t.threadId!==thId);
  ws.threads=ws.threads.filter(t=>t.id!==thId);
  ws.tasks.forEach(k=>{if(k.threadId===thId)k.threadId=null});
  if(!ws.tabs.some(t=>t.id===ws.active)&&ws.active!=="motherboard")ws.active="home";
  saveWs();render();
}
function reopenThread(thId){
  const th=threadOf(thId);if(!th)return;
  const has=ws.tabs.find(t=>t.threadId===thId);
  if(has){th.collapsed=false;ws.active=has.id}
  else{let first=null;for(const tool of KINDS[th.kind].tools){const t=openTool(tool,thId,false);first=first||t}ws.active=first.id}
  saveWs();render();
}
function renderStrip(){
  const el=document.getElementById("strip");el.innerHTML="";
  const mk=(id,label,opts={})=>{
    const b=document.createElement("div");b.className="tab";b.setAttribute("role","tab");b.tabIndex=0;
    b.setAttribute("aria-selected",ws.active===id);
    if(opts.group){b.dataset.group="1";b.style.setProperty("--g",opts.group)}
    const l=document.createElement("span");l.className="label";l.textContent=label;b.append(l);
    if(opts.closable){const x=document.createElement("button");x.className="x";x.type="button";x.setAttribute("aria-label","Close "+label);x.textContent="×";
      x.onclick=(e)=>{e.stopPropagation();closeTab(id)};b.append(x)}
    const go=()=>{ws.active=id;saveWs();render()};
    b.onclick=go;b.onkeydown=(e)=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();go()}};
    el.append(b);
  };
  mk("home","Home");mk("motherboard","Motherboard",{group:"var(--sys)"});
  const seen=new Set();
  for(const t of ws.tabs){
    const th=t.threadId&&threadOf(t.threadId);
    if(th&&!seen.has(th.id)){
      seen.add(th.id);
      const c=document.createElement("button");c.className="chip";c.type="button";c.style.setProperty("--g",gColor(th.kind));
      c.textContent=th.title;c.setAttribute("aria-expanded",!th.collapsed);c.title="Tap to collapse. Long-press or right-click to close the workflow.";
      c.onclick=()=>{th.collapsed=!th.collapsed;if(th.collapsed&&ws.tabs.find(x=>x.id===ws.active)?.threadId===th.id)ws.active="home";saveWs();render()};
      c.oncontextmenu=(e)=>{e.preventDefault();closeThread(th.id)};
      el.append(c);
    }
    if(th&&th.collapsed)continue;
    mk(t.id,TOOLS[t.tool].name,{closable:true,group:th?gColor(th.kind):null});
  }
  const add=document.createElement("button");add.className="addtab";add.type="button";add.textContent="+";add.setAttribute("aria-label","Open a tool");
  add.onclick=openLauncher;el.append(add);
  el.querySelector('[aria-selected="true"]')?.scrollIntoView({block:"nearest",inline:"nearest"});
}

/* ============ Home ============ */
const URG=["now","today","later"];
function renderHome(m){
  const d=new Date();
  m.innerHTML=`<h1>${esc(d.toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long"}))}</h1>
  <p class="sub">Start a workflow, then work the day top to bottom. Drag tasks to reprioritise.</p>
  <div class="launch" id="launch"></div>
  <div class="home"><section aria-labelledby="dp"><h2 id="dp">Day plan</h2>
    <form class="addrow" id="addf"><label class="sr" for="nt">New task</label><input id="nt" placeholder="Add a task, e.g. Call Mo re Ealing feedback" maxlength="300" autocomplete="off">
    <select id="nl" aria-label="Time block">${LANES.map(l=>`<option value="${l.id}">${esc(l.name)}</option>`).join("")}</select>
    <select id="nth" aria-label="Link to workflow"><option value="">No workflow</option>${ws.threads.map(t=>`<option value="${esc(t.id)}">${esc(t.title)}</option>`).join("")}</select>
    <button class="btn primary">Add</button></form>
    <div id="lanes"></div></section>
  <aside><div class="panel"><h2>Open workflows</h2><div id="threads"></div></div>
  <div class="panel" style="margin-top:12px"><h2>Your settings</h2><button class="btn" id="setb" type="button">Edit name, house rules and writing style</button>
  <p class="status" style="margin:10px 0 0">Signed in as ${esc(me.email)}.</p>
  <button class="btn small" id="clrdone" type="button" style="margin-top:8px">Clear ticked tasks</button></div></aside></div>`;
  const L=m.querySelector("#launch");
  for(const [k,v] of Object.entries(KINDS)){
    const b=document.createElement("button");b.className="wf";b.type="button";b.style.setProperty("--g",gColor(k));
    b.innerHTML=`<strong>${esc(v.label)}</strong><span>${esc(v.blurb)}</span>`;b.onclick=()=>askThread(k);L.append(b);
  }
  m.querySelector("#addf").onsubmit=(e)=>{e.preventDefault();const t=m.querySelector("#nt").value.trim();if(!t)return;
    ws.tasks.unshift({id:uid(),text:t,lane:m.querySelector("#nl").value,urgency:"today",done:false,threadId:m.querySelector("#nth").value||null});
    saveWs();renderHome(m);m.querySelector("#nt").focus()};
  m.querySelector("#setb").onclick=openSettings;
  m.querySelector("#clrdone").onclick=()=>{const n=ws.tasks.filter(t=>t.done).length;if(!n)return;if(!confirm(`Remove ${n} ticked task${n>1?"s":""}?`))return;ws.tasks=ws.tasks.filter(t=>!t.done);saveWs();renderHome(m)};
  const lanes=m.querySelector("#lanes");
  for(const l of LANES){
    const items=ws.tasks.filter(t=>t.lane===l.id);const open=items.filter(t=>!t.done).length;
    const wrap=document.createElement("div");wrap.className="lane";
    wrap.innerHTML=`<div class="lane-head"><h3>${esc(l.name)}</h3><small>${open} open · ${esc(l.hint)}</small></div>`;
    const ul=document.createElement("ul");ul.className="list";ul.dataset.lane=l.id;
    if(!items.length){const e=document.createElement("li");e.className="empty";e.textContent="Drop a task here.";ul.append(e)}
    for(const t of items)ul.append(taskEl(t));
    wrap.append(ul);lanes.append(wrap);
  }
  const tl=m.querySelector("#threads");
  if(!ws.threads.length)tl.innerHTML=`<p class="empty">No workflows yet. Start one above.</p>`;
  for(const th of ws.threads){
    const r=document.createElement("div");r.className="thread";r.style.setProperty("--g",gColor(th.kind));
    const n=ws.tasks.filter(t=>t.threadId===th.id&&!t.done).length;
    r.innerHTML=`<span class="dot"></span>`;
    const b=document.createElement("button");b.className="link";b.type="button";b.textContent=th.title;b.onclick=()=>reopenThread(th.id);
    const s=document.createElement("small");s.className="status";s.textContent=n?`${n} task${n>1?"s":""}`:"";
    const x=document.createElement("button");x.className="btn small";x.type="button";x.textContent="Close";x.onclick=()=>closeThread(th.id);
    r.append(b,s,x);tl.append(r);
  }
}
function taskEl(t){
  const li=document.createElement("li");li.className="task"+(t.done?" done":"");li.dataset.id=t.id;
  const h=document.createElement("button");h.className="handle";h.type="button";h.textContent="⠿";h.setAttribute("aria-label","Drag to reorder, or use arrow keys");
  h.onpointerdown=(e)=>dragStart(e,li);
  h.onkeydown=(e)=>{if(e.key==="ArrowUp"||e.key==="ArrowDown"){e.preventDefault();moveTask(t.id,e.key==="ArrowUp"?-1:1)}};
  const cb=document.createElement("input");cb.type="checkbox";cb.checked=t.done;cb.setAttribute("aria-label","Done: "+t.text);
  cb.onchange=()=>{t.done=cb.checked;saveWs();rerenderHome()};
  const tx=document.createElement("div");tx.className="ttext";tx.textContent=t.text;
  const th=t.threadId&&threadOf(t.threadId);
  if(th){const s=document.createElement("small");s.textContent=th.title;tx.append(s)}
  if(t.waitingOn){const s=document.createElement("small");s.textContent="Waiting on: "+t.waitingOn;tx.append(s)}
  const u=document.createElement("button");u.className="urg";u.type="button";u.dataset.u=t.urgency;u.textContent=t.urgency;u.title="Change urgency";
  u.onclick=()=>{t.urgency=URG[(URG.indexOf(t.urgency)+1)%3];saveWs();rerenderHome()};
  const more=document.createElement("button");more.className="btn small";more.type="button";more.textContent="…";more.setAttribute("aria-label","Task options");
  more.onclick=()=>taskMenu(t);
  li.append(h,cb,tx,u,more);return li;
}
function rerenderHome(){if(ws.active==="home")renderHome(document.getElementById("main"))}
function moveTask(id,dir){
  const t=ws.tasks.find(x=>x.id===id);const same=ws.tasks.filter(x=>x.lane===t.lane);
  const j=same.indexOf(t)+dir;if(j<0||j>=same.length)return;
  const a=ws.tasks.indexOf(t),b=ws.tasks.indexOf(same[j]);[ws.tasks[a],ws.tasks[b]]=[ws.tasks[b],ws.tasks[a]];
  saveWs();rerenderHome();document.querySelector(`.task[data-id="${CSS.escape(id)}"] .handle`)?.focus();
}
function dragStart(e,li){
  e.preventDefault();li.classList.add("dragging");
  const tgt=e.target;tgt.setPointerCapture(e.pointerId);
  const mv=(ev)=>{
    const el=document.elementFromPoint(ev.clientX,ev.clientY);if(!el)return;
    document.querySelectorAll(".list.over").forEach(x=>x.classList.remove("over"));
    const list=el.closest(".list");if(!list)return;list.classList.add("over");
    list.querySelector(".empty")?.remove();
    const over=el.closest(".task");
    if(over&&over!==li){const r=over.getBoundingClientRect();list.insertBefore(li,ev.clientY<r.top+r.height/2?over:over.nextSibling)}
    else if(!over)list.append(li);
    if(ev.clientY<60)scrollBy(0,-12);else if(ev.clientY>innerHeight-60)scrollBy(0,12);
  };
  const up=()=>{
    tgt.removeEventListener("pointermove",mv);tgt.removeEventListener("pointerup",up);tgt.removeEventListener("pointercancel",up);
    li.classList.remove("dragging");document.querySelectorAll(".list.over").forEach(x=>x.classList.remove("over"));
    const byId=new Map(ws.tasks.map(t=>[t.id,t]));const next=[];
    document.querySelectorAll(".list").forEach(ul=>ul.querySelectorAll(".task").forEach(n=>{const t=byId.get(n.dataset.id);if(t){t.lane=ul.dataset.lane;next.push(t);byId.delete(t.id)}}));
    ws.tasks=[...next,...byId.values()];saveWs();rerenderHome();say("Task moved.");
  };
  tgt.addEventListener("pointermove",mv);tgt.addEventListener("pointerup",up);tgt.addEventListener("pointercancel",up);
}
function taskMenu(t){
  const d=document.getElementById("dlg");
  d.innerHTML=`<h2>Task</h2><label>Text<input id="tt" maxlength="300"></label>
  <label style="margin-top:10px">Waiting on (moves it to “Waiting on”)<input id="tw" placeholder="e.g. Client feedback on CV" maxlength="200"></label>
  <label style="margin-top:10px">Workflow<select id="tth"><option value="">None</option>${ws.threads.map(x=>`<option value="${esc(x.id)}">${esc(x.title)}</option>`).join("")}</select></label>
  <div class="row"><button class="btn" id="tdel" type="button" style="color:var(--danger)">Delete</button>${t.threadId?'<button class="btn" id="topen" type="button">Open workflow</button>':""}<button class="btn" id="tc" type="button">Cancel</button><button class="btn primary" id="ts" type="button">Save</button></div>`;
  d.querySelector("#tt").value=t.text;d.querySelector("#tw").value=t.waitingOn||"";d.querySelector("#tth").value=t.threadId||"";
  d.querySelector("#tc").onclick=()=>d.close();
  d.querySelector("#tdel").onclick=()=>{ws.tasks=ws.tasks.filter(x=>x!==t);saveWs();d.close();rerenderHome()};
  const op=d.querySelector("#topen");if(op)op.onclick=()=>{d.close();reopenThread(t.threadId)};
  d.querySelector("#ts").onclick=()=>{
    t.text=d.querySelector("#tt").value.trim()||t.text;
    const w=d.querySelector("#tw").value.trim();
    if(w&&!t.waitingOn){t.prevLane=t.lane;t.lane="waiting"}
    if(!w&&t.waitingOn&&t.lane==="waiting")t.lane=t.prevLane||"morning";
    t.waitingOn=w||null;t.threadId=d.querySelector("#tth").value||null;
    saveWs();d.close();rerenderHome()};
  d.showModal();
}

/* ============ Dialogs ============ */
function askThread(kind){
  const d=document.getElementById("dlg");const K=KINDS[kind];
  const ph=kind==="candidate"?"e.g. Mo Bhamji, PQS":kind==="job"?"e.g. City Central, AQS Ealing":"e.g. Fit-out, West London";
  d.innerHTML=`<h2>${esc(K.label)}</h2><p class="sub">Name the thread so you can find it again. Details carry into every tab.</p>
  <label>Thread name<input id="tn" placeholder="${esc(ph)}" maxlength="80"></label>
  <div class="grid2">${CTX_FIELDS.map(([k,l])=>`<label>${esc(l)}${k==="notes"?`<textarea id="c_${k}" style="min-height:60px" maxlength="2000"></textarea>`:`<input id="c_${k}" maxlength="200">`}</label>`).join("")}</div>
  <p class="status">Opens: ${K.tools.map(t=>esc(TOOLS[t].name)).join(", ")}</p>
  <div class="row"><button class="btn" id="cc" type="button">Cancel</button><button class="btn primary" id="cs" type="button">Open workflow</button></div>`;
  d.querySelector("#cc").onclick=()=>d.close();
  d.querySelector("#cs").onclick=()=>{
    const title=d.querySelector("#tn").value.trim();if(!title){d.querySelector("#tn").focus();return}
    const ctx={};CTX_FIELDS.forEach(([k])=>ctx[k]=d.querySelector("#c_"+k).value.trim());
    d.close();startWorkflow(kind,title,ctx)};
  d.showModal();d.querySelector("#tn").focus();
}
function openLauncher(){
  const d=document.getElementById("dlg");
  const act=ws.tabs.find(t=>t.id===ws.active);const th=act&&act.threadId&&threadOf(act.threadId);
  d.innerHTML=`<h2>Open a tool</h2>${th?`<p class="sub">Adds to “${esc(th.title)}”.</p>`:`<p class="sub">Opens on its own. Start a workflow from Home to group tabs.</p>`}
  <div class="menu">${Object.entries(TOOLS).map(([k,v])=>`<button class="btn" type="button" data-k="${k}">${esc(v.name)}</button>`).join("")}</div>
  <div class="row"><button class="btn" id="lc" type="button">Cancel</button></div>`;
  d.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>{d.close();openTool(b.dataset.k,th?th.id:null);render()});
  d.querySelector("#lc").onclick=()=>d.close();d.showModal();
}
function openSettings(){
  const d=document.getElementById("dlg");const s=ws.settings;
  d.innerHTML=`<h2>Settings</h2>
  <label>Sign-off name<input id="sn" maxlength="60"></label>
  <label style="margin-top:10px">House rules<textarea id="sh" maxlength="5000"></textarea></label>
  <label style="margin-top:10px">Your writing style (paste 2–3 messages you’ve sent)<textarea id="ss" style="min-height:160px" maxlength="20000"></textarea></label>
  <label style="margin-top:10px">LinkedIn string character limit<input id="sl" type="number" min="200" max="10000"></label>
  <div class="row"><button class="btn" id="sc" type="button">Cancel</button><button class="btn primary" id="sv" type="button">Save settings</button></div>`;
  d.querySelector("#sn").value=s.name;d.querySelector("#sh").value=s.houseRules;d.querySelector("#ss").value=s.styleSamples;d.querySelector("#sl").value=s.stringLimit;
  d.querySelector("#sc").onclick=()=>d.close();
  d.querySelector("#sv").onclick=()=>{s.name=d.querySelector("#sn").value.trim();s.houseRules=d.querySelector("#sh").value;s.styleSamples=d.querySelector("#ss").value;
    s.stringLimit=Math.min(10000,Math.max(200,parseInt(d.querySelector("#sl").value,10)||1000));saveWs();d.close();say("Settings saved.")};
  d.showModal();
}

/* ============ Motherboard ============ */
const MB_SCHEMA=[
  ["Candidates","Star, Name, Number, Current employer, Level, Location, Salary, Notice, Main con / Developer, Skills, Reason for looking, Temperature, Last contacted, Next follow-up, Notes"],
  ["B Rate","Same columns as Candidates"],
  ["Jobs","Job title, Client, Location, Salary, Level, Job status, Date opened, Next client follow-up, Notes"],
  ["Submissions","Date submitted, Candidate, Rate, Client, Job title, Stage, Awaiting feedback from, Outcome / reason"],
  ["Activity","Date, Name, Contact method, Summary, Agreed next step, Follow-up date, Related job"],
  ["Clients","Name, Number, Company, Role, Location, Main con / Developer, Last contacted, Notes"],
  ["Non-commercial","Name, Number, Position, Location, Email, Notes"]
];
async function renderMotherboard(m){
  const open=ws.tasks.filter(t=>!t.done).length;
  m.innerHTML=`<h1>Motherboard</h1><p class="sub">The system of record. Every tab feeds back here.</p>
  <div class="panel"><h2>Lusha lookups</h2><div id="lk"><p class="status">Loading…</p></div></div>
  <div class="panel" style="margin-top:12px"><h2>In this workspace</h2><p>${ws.threads.length} open workflow${ws.threads.length===1?"":"s"}, ${open} open task${open===1?"":"s"}, ${ws.tasks.filter(t=>t.lane==="waiting"&&!t.done).length} waiting.</p></div>
  <div class="panel" style="margin-top:12px"><h2>Google Sheets sync (next build)</h2><div class="scrollx"><table><thead><tr><th>Tab</th><th>Columns</th></tr></thead><tbody>
  ${MB_SCHEMA.map(([a,b])=>`<tr><td><strong>${esc(a)}</strong></td><td>${esc(b)}</td></tr>`).join("")}</tbody></table></div></div>`;
  const box=m.querySelector("#lk");
  try{
    const {items}=await api("GET","/api/lusha/recent");
    if(ws.active!=="motherboard")return;
    if(!items.length){box.innerHTML=`<p class="empty">No lookups yet. Run one from a Lusha tab.</p>`;return}
    const rows=items.map(it=>{
      const q=it.query||{};const who=[q.firstName,q.lastName].filter(Boolean).join(" ")||q.email||q.linkedinUrl||"—";
      const res=it.status===200&&it.data?formatContact(it.data).split("\n").slice(1).join("; "):it.status===404?"No match":"Failed ("+it.status+")";
      return `<tr><td>${esc(new Date(it.at).toLocaleString("en-GB",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}))}</td><td>${esc(who)}${q.companyName?"<br><small>"+esc(q.companyName)+"</small>":""}</td><td>${esc(res)}</td><td>${it.charged?"Yes":"No"}</td></tr>`;
    }).join("");
    box.innerHTML=`<div class="scrollx"><table><thead><tr><th>When</th><th>Searched</th><th>Result</th><th>Credit</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }catch(e){box.innerHTML=`<p class="err">${esc(e.message)}</p>`}
}

/* ============ Tool view ============ */
async function renderTool(m,tab){
  const T=TOOLS[tab.tool];const th=tab.threadId&&threadOf(tab.threadId);
  if(!tabData.has(tab.id)){
    m.innerHTML=`<p class="status">Loading…</p>`;
    let d=null;try{d=(await api("GET","/api/tabs/"+tab.id)).data}catch(e){showBanner("Couldn’t load tab: "+e.message)}
    tabData.set(tab.id,d&&typeof d==="object"?{inputs:d.inputs||{},output:S(d.output),at:d.at||0}:{inputs:{},output:"",at:0});
    if(ws.active!==tab.id)return;
  }
  const D=tabData.get(tab.id);
  m.innerHTML="";
  const h=document.createElement("h1");h.textContent=T.name;const p=document.createElement("p");p.className="sub";p.textContent=T.desc;m.append(h,p);
  if(th){
    const det=document.createElement("details");det.className="panel ctx";det.style.setProperty("--g",gColor(th.kind));
    det.innerHTML=`<summary>${esc(th.title)}<span class="status"> · shared by every tab in this workflow</span></summary><div class="grid2">${CTX_FIELDS.map(([k,l])=>`<label>${esc(l)}<input data-c="${k}" maxlength="${k==="notes"?2000:200}"></label>`).join("")}</div>`;
    det.querySelectorAll("[data-c]").forEach(inp=>{inp.value=S(th.ctx[inp.dataset.c]);inp.oninput=()=>{th.ctx[inp.dataset.c]=inp.value;saveWs()}});
    m.append(det);
  }
  const wrap=document.createElement("div");wrap.className="tool";
  const left=document.createElement("div");left.className="panel fields";
  for(const f of T.fields){
    const lab=document.createElement("label");lab.textContent=f.label+(f.req?"":" (optional)");let inp;
    if(f.sel){inp=document.createElement("select");f.sel.forEach(o=>{const op=document.createElement("option");op.textContent=o;inp.append(op)})}
    else if(f.area){inp=document.createElement("textarea");if(f.big)inp.style.minHeight="220px";inp.maxLength=60000}
    else{inp=document.createElement("input");if(f.num)inp.type="number";inp.maxLength=500}
    let v=D.inputs[f.k];
    if(v===undefined)v=f.k==="limit"?ws.settings.stringLimit:f.ctx&&th?S(th.ctx[f.ctx]):S(f.val);
    inp.value=v;
    inp.oninput=inp.onchange=()=>{D.inputs[f.k]=inp.value;saveTab(tab.id)};
    lab.append(inp);left.append(lab);
  }
  const run=document.createElement("button");run.className="btn primary";run.type="button";run.textContent=tab.tool==="lusha"?"Look up":"Generate";
  const st=document.createElement("p");st.className="status";st.style.margin="0";
  const needs=T.needs||"ai";
  if(!me[needs]){run.disabled=true;st.textContent=needs==="lusha"?"Lusha isn’t configured on the server yet.":"AI isn’t configured on the server yet."}
  left.append(run,st);
  const right=document.createElement("div");right.className="panel";
  const bar=document.createElement("div");bar.className="outbar";
  const cp=document.createElement("button");cp.className="btn small";cp.type="button";cp.textContent="Copy";
  const tk=document.createElement("button");tk.className="btn small";tk.type="button";tk.textContent="Add follow-up task";
  const when=document.createElement("span");when.className="status";bar.append(cp,tk,when);
  const out=document.createElement("div");out.className="out";out.setAttribute("aria-live","polite");
  const paint=()=>{out.textContent=D.output||"Output appears here.";out.style.color=D.output?"":"var(--muted)";
    when.textContent=D.at?"Generated "+new Date(D.at).toLocaleTimeString("en-GB",{hour:"2-digit",minute:"2-digit"}):"";cp.disabled=tk.disabled=!D.output};
  paint();right.append(bar,out);
  cp.onclick=async()=>{try{await navigator.clipboard.writeText(D.output);cp.textContent="Copied"}catch{const r=document.createRange();r.selectNodeContents(out);const s=getSelection();s.removeAllRanges();s.addRange(r);cp.textContent="Selected, press copy"}setTimeout(()=>cp.textContent="Copy",1500)};
  tk.onclick=()=>{ws.tasks.unshift({id:uid(),text:`${T.name}: follow up${th?" on "+th.title:""}`,lane:tab.tool==="bdmanager"||tab.tool==="mapping"?"afternoon":"morning",urgency:"today",done:false,threadId:th?th.id:null});saveWs();tk.textContent="Added to Home";setTimeout(()=>tk.textContent="Add follow-up task",1500)};
  run.onclick=async()=>{
    const inputs={};T.fields.forEach(f=>{let v=D.inputs[f.k];if(v===undefined)v=f.sel?f.sel[0]:f.k==="limit"?ws.settings.stringLimit:f.ctx&&th?S(th.ctx[f.ctx]):S(f.val);inputs[f.k]=S(v).trim()});
    const missing=T.fields.filter(f=>f.req&&!inputs[f.k]).map(f=>f.label);
    const vErr=missing.length?"Fill in: "+missing.join(", ")+".":T.validate?T.validate(inputs):null;
    if(vErr){st.className="status err";st.textContent=vErr;return}
    run.disabled=true;st.className="status";st.textContent=tab.tool==="lusha"?"Looking up…":"Generating…";
    try{D.output=await T.run(inputs,th,ws.settings);D.at=Date.now();saveTab(tab.id);st.textContent=tab.tool==="lusha"?"Done. Logged to the Motherboard.":"Done. Check facts before sending."}
    catch(e){console.error(tab.tool,e);st.className="status err";st.textContent=e.message||"Failed."}
    finally{run.disabled=false;if(ws.active===tab.id)paint()}
  };
  wrap.append(left,right);m.append(wrap);
}

/* ============ Boot ============ */
function render(){
  renderStrip();
  const m=document.getElementById("main");
  if(ws.active==="home")return renderHome(m);
  if(ws.active==="motherboard")return renderMotherboard(m);
  const tab=ws.tabs.find(t=>t.id===ws.active);
  if(!tab){ws.active="home";return renderHome(m)}
  renderTool(m,tab);
}
function sanitize(w){
  const d=DEFAULT_WS();if(!w||typeof w!=="object")return d;
  const out={...d,...w,settings:{...d.settings,...(w.settings||{})}};
  out.tasks=Array.isArray(w.tasks)?w.tasks.filter(t=>t&&t.id&&LANES.some(l=>l.id===t.lane)):[];
  out.threads=Array.isArray(w.threads)?w.threads.filter(t=>t&&t.id&&KINDS[t.kind]).map(t=>({...t,ctx:t.ctx||{}})):[];
  out.tabs=Array.isArray(w.tabs)?w.tabs.filter(t=>t&&t.id&&TOOLS[t.tool]&&(!t.threadId||out.threads.some(x=>x.id===t.threadId))):[];
  return out;
}
async function boot(){
  try{
    me=await api("GET","/api/me");
    const r=await api("GET","/api/workspace");
    ws=sanitize(r.data);wsVersion=r.version;
    render();
  }catch(e){
    console.error("boot",e);
    document.getElementById("main").innerHTML=`<h1>Can’t load your desk</h1><p class="err">${esc(e.message)}</p><button class="btn" type="button" id="rl">Reload</button>`;
    document.getElementById("rl").onclick=()=>location.reload();
  }
}
boot();
