export interface Env {
  ASSETS: Fetcher;
  DB: D1Database;
  ACCESS_TEAM_DOMAIN: string;
  ACCESS_AUD: string;
  AI_MODEL: string;
  AI_DAILY_CAP: string;
  LUSHA_DAILY_CAP: string;
  ANTHROPIC_API_KEY?: string;
  LUSHA_API_KEY?: string;
  /** Local dev only (.dev.vars). Honoured solely on localhost. */
  DEV_USER_EMAIL?: string;
}
