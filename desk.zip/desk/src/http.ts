export class HttpError extends Error {
  constructor(public status: number, public code: string, message: string, public extra?: Record<string, unknown>) {
    super(message);
  }
}

const SEC_HEADERS: Record<string, string> = {
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "same-origin",
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...SEC_HEADERS },
  });
}

export function errorResponse(e: unknown, reqId: string): Response {
  if (e instanceof HttpError) {
    return json({ error: { code: e.code, message: e.message, reqId, ...e.extra } }, e.status);
  }
  // Unknown: log full detail server-side, return opaque id to client.
  console.error(JSON.stringify({ reqId, level: "error", err: e instanceof Error ? { name: e.name, message: e.message, stack: e.stack } : String(e) }));
  return json({ error: { code: "internal", message: "Something failed on the server.", reqId } }, 500);
}

/** Read a JSON body with a hard size limit. */
export async function readJson<T>(req: Request, maxBytes: number): Promise<T> {
  const len = Number(req.headers.get("Content-Length") || "0");
  if (len > maxBytes) throw new HttpError(413, "too_large", `Body over ${maxBytes} bytes.`);
  const text = await req.text();
  if (text.length > maxBytes) throw new HttpError(413, "too_large", `Body over ${maxBytes} bytes.`);
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new HttpError(400, "bad_json", "Body is not valid JSON.");
  }
}

export const todayUtc = () => new Date().toISOString().slice(0, 10);
