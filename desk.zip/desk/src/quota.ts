import type { Env } from "./env";
import { HttpError, todayUtc } from "./http";

/** Atomically increments today's counter; throws if it would exceed the cap. */
export async function consume(env: Env, user: string, kind: "ai" | "lusha", cap: number): Promise<void> {
  const day = todayUtc();
  const row = await env.DB.prepare(
    `INSERT INTO usage (user_email, day, kind, count) VALUES (?1, ?2, ?3, 1)
     ON CONFLICT (user_email, day, kind) DO UPDATE SET count = count + 1
     WHERE count < ?4
     RETURNING count`
  ).bind(user, day, kind, cap).first<{ count: number }>();
  if (!row) throw new HttpError(429, "quota", `Daily ${kind} limit (${cap}) reached. Resets at midnight UTC.`);
}

/** Refund a unit when the paid call didn't happen or wasn't charged. */
export async function refund(env: Env, user: string, kind: "ai" | "lusha"): Promise<void> {
  await env.DB.prepare(`UPDATE usage SET count = MAX(count - 1, 0) WHERE user_email = ?1 AND day = ?2 AND kind = ?3`)
    .bind(user, todayUtc(), kind).run();
}

export async function audit(env: Env, user: string, action: string, detail?: unknown): Promise<void> {
  await env.DB.prepare(`INSERT INTO audit (user_email, action, detail, at) VALUES (?1, ?2, ?3, ?4)`)
    .bind(user, action, detail === undefined ? null : JSON.stringify(detail).slice(0, 2000), Date.now()).run();
}
