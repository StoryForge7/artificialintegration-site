import type { Env } from "./env";
import { HttpError } from "./http";

/**
 * Verifies the Cloudflare Access JWT (Cf-Access-Jwt-Assertion).
 * Access must also be enforced at the edge on the hostname; this is defence in depth
 * so the API is never reachable unauthenticated even if the Access app is misconfigured.
 */
interface Jwk { kid: string; kty: string; n: string; e: string; alg?: string }
let jwksCache: { at: number; keys: Map<string, CryptoKey>; team: string } | null = null;
const JWKS_TTL_MS = 60 * 60 * 1000;

const b64urlToBytes = (s: string): Uint8Array => {
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(s.length / 4) * 4, "=");
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
};

async function getKeys(team: string, forceRefresh = false): Promise<Map<string, CryptoKey>> {
  if (!forceRefresh && jwksCache && jwksCache.team === team && Date.now() - jwksCache.at < JWKS_TTL_MS) return jwksCache.keys;
  const res = await fetch(`https://${team}/cdn-cgi/access/certs`, { signal: AbortSignal.timeout(5000) });
  if (!res.ok) throw new HttpError(503, "auth_unavailable", `Access certs fetch failed (${res.status}).`);
  const body = (await res.json()) as { keys?: Jwk[] };
  const keys = new Map<string, CryptoKey>();
  for (const k of body.keys ?? []) {
    if (k.kty !== "RSA") continue;
    keys.set(k.kid, await crypto.subtle.importKey("jwk", { kty: k.kty, n: k.n, e: k.e, alg: "RS256", ext: true },
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]));
  }
  jwksCache = { at: Date.now(), keys, team };
  return keys;
}

export async function requireUser(req: Request, env: Env): Promise<string> {
  const url = new URL(req.url);
  const isLocal = url.hostname === "localhost" || url.hostname === "127.0.0.1";
  if (env.DEV_USER_EMAIL) {
    if (!isLocal) throw new HttpError(500, "misconfigured", "DEV_USER_EMAIL must not be set outside local dev.");
    return env.DEV_USER_EMAIL.toLowerCase();
  }
  if (!env.ACCESS_TEAM_DOMAIN || env.ACCESS_TEAM_DOMAIN.startsWith("REPLACE") || !env.ACCESS_AUD || env.ACCESS_AUD.startsWith("REPLACE")) {
    throw new HttpError(500, "misconfigured", "ACCESS_TEAM_DOMAIN / ACCESS_AUD not configured.");
  }
  const token = req.headers.get("Cf-Access-Jwt-Assertion");
  if (!token) throw new HttpError(401, "unauthenticated", "Sign in through Cloudflare Access.");

  const parts = token.split(".");
  if (parts.length !== 3) throw new HttpError(401, "bad_token", "Malformed token.");
  const [h, p, s] = parts as [string, string, string];
  let header: { kid?: string; alg?: string };
  let payload: { aud?: string | string[]; iss?: string; exp?: number; nbf?: number; email?: string };
  try {
    header = JSON.parse(new TextDecoder().decode(b64urlToBytes(h)));
    payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(p)));
  } catch {
    throw new HttpError(401, "bad_token", "Malformed token.");
  }
  if (header.alg !== "RS256" || !header.kid) throw new HttpError(401, "bad_token", "Unsupported token.");

  let keys = await getKeys(env.ACCESS_TEAM_DOMAIN);
  let key = keys.get(header.kid);
  if (!key) { keys = await getKeys(env.ACCESS_TEAM_DOMAIN, true); key = keys.get(header.kid); } // key rotation
  if (!key) throw new HttpError(401, "bad_token", "Unknown signing key.");

  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64urlToBytes(s), new TextEncoder().encode(`${h}.${p}`));
  if (!ok) throw new HttpError(401, "bad_token", "Invalid signature.");

  const now = Math.floor(Date.now() / 1000);
  const aud = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
  if (!aud.includes(env.ACCESS_AUD)) throw new HttpError(401, "bad_token", "Wrong audience.");
  if (payload.iss !== `https://${env.ACCESS_TEAM_DOMAIN}`) throw new HttpError(401, "bad_token", "Wrong issuer.");
  if (!payload.exp || payload.exp < now - 30) throw new HttpError(401, "expired", "Session expired. Reload to sign in.");
  if (payload.nbf && payload.nbf > now + 30) throw new HttpError(401, "bad_token", "Token not yet valid.");
  if (!payload.email) throw new HttpError(403, "no_email", "Access identity has no email.");
  return payload.email.toLowerCase();
}

/** CSRF: mutating requests must be same-origin and carry the app header. */
export function requireSameOrigin(req: Request): void {
  if (req.method === "GET" || req.method === "HEAD") return;
  const origin = req.headers.get("Origin");
  const host = new URL(req.url).origin;
  if (!origin || origin !== host) throw new HttpError(403, "bad_origin", "Cross-origin request refused.");
  if (req.headers.get("X-Desk") !== "1") throw new HttpError(403, "bad_origin", "Missing app header.");
}
