import type { Env } from "./env";
import { HttpError } from "./http";
import { audit, consume, refund } from "./quota";

/** Mirrors Lusha GET /v2/person search requirements. */
export interface PersonQuery { linkedinUrl?: string; email?: string; firstName?: string; lastName?: string; companyName?: string; companyDomain?: string }
const CACHE_DAYS = 30;
const FIELDS: (keyof PersonQuery)[] = ["linkedinUrl", "email", "firstName", "lastName", "companyName", "companyDomain"];

function normalise(q: PersonQuery): PersonQuery {
  const out: PersonQuery = {};
  for (const k of FIELDS) {
    const v = typeof q?.[k] === "string" ? q[k]!.trim().slice(0, 300) : "";
    if (v) out[k] = v;
  }
  if (out.linkedinUrl && !/^https:\/\/([a-z]{2,3}\.)?linkedin\.com\/in\//i.test(out.linkedinUrl)) throw new HttpError(400, "bad_request", "LinkedIn URL must look like https://www.linkedin.com/in/…");
  if (out.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(out.email)) throw new HttpError(400, "bad_request", "Email looks invalid.");
  const byName = out.firstName && out.lastName && (out.companyName || out.companyDomain);
  if (!out.linkedinUrl && !out.email && !byName) {
    throw new HttpError(400, "bad_request", "Give a LinkedIn URL, an email, or first + last name with a company name or domain.");
  }
  return out;
}

export async function lushaPerson(env: Env, user: string, raw: PersonQuery) {
  const q = normalise(raw);
  const key = FIELDS.map((k) => `${k}=${(q[k] ?? "").toLowerCase()}`).join("&");

  // Cache: never pay twice for the same query within CACHE_DAYS.
  const since = Date.now() - CACHE_DAYS * 864e5;
  const hit = await env.DB.prepare(
    `SELECT response_json, created_at FROM lusha_lookup WHERE user_email = ?1 AND query_key = ?2 AND status = 200 AND created_at > ?3 ORDER BY created_at DESC LIMIT 1`
  ).bind(user, key, since).first<{ response_json: string; created_at: number }>();
  if (hit) return { cached: true, at: hit.created_at, result: JSON.parse(hit.response_json) };

  if (!env.LUSHA_API_KEY) throw new HttpError(503, "lusha_not_configured", "LUSHA_API_KEY secret is not set.");
  await consume(env, user, "lusha", Number(env.LUSHA_DAILY_CAP) || 40);

  const url = new URL("https://api.lusha.com/v2/person");
  for (const k of FIELDS) if (q[k]) url.searchParams.set(k, q[k]!);
  let res: Response;
  try {
    res = await fetch(url, { headers: { api_key: env.LUSHA_API_KEY, accept: "application/json" }, signal: AbortSignal.timeout(20_000) });
  } catch {
    await refund(env, user, "lusha");
    throw new HttpError(504, "lusha_timeout", "Lusha didn’t respond in time.");
  }
  const text = await res.text();
  let body: any = null;
  try { body = JSON.parse(text); } catch { /* keep null */ }
  const charged = body?.contact?.isCreditCharged === true;
  if (!charged) await refund(env, user, "lusha");

  await env.DB.prepare(
    `INSERT INTO lusha_lookup (id, user_email, query_key, query_json, response_json, credit_charged, status, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)`
  ).bind(crypto.randomUUID(), user, key, JSON.stringify(q), body ? JSON.stringify(body) : text.slice(0, 2000), charged ? 1 : 0, res.status, Date.now()).run();
  await audit(env, user, "lusha.person", { status: res.status, charged });

  if (res.status === 401) throw new HttpError(502, "lusha_auth", "Lusha rejected the API key.");
  if (res.status === 403) throw new HttpError(502, "lusha_forbidden", "Lusha refused the request. Check your plan includes API access.");
  if (res.status === 429) throw new HttpError(429, "rate_limited", "Lusha rate limit hit. Try again shortly.");
  if (res.status === 404) return { cached: false, at: Date.now(), result: null };
  if (!res.ok) throw new HttpError(502, "lusha_upstream", `Lusha request failed (${res.status}).`);
  return { cached: false, at: Date.now(), result: body };
}

export async function recentLookups(env: Env, user: string) {
  const { results } = await env.DB.prepare(
    `SELECT id, query_json, response_json, credit_charged, status, created_at FROM lusha_lookup WHERE user_email = ?1 ORDER BY created_at DESC LIMIT 100`
  ).bind(user).all<{ id: string; query_json: string; response_json: string | null; credit_charged: number; status: number; created_at: number }>();
  return results.map((r) => {
    let data: any = null;
    try { data = JSON.parse(r.response_json ?? "null")?.contact?.data ?? null; } catch { /* raw text */ }
    return { id: r.id, query: JSON.parse(r.query_json), data, charged: !!r.credit_charged, status: r.status, at: r.created_at };
  });
}
