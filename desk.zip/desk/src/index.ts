import type { Env } from "./env";
import { errorResponse, HttpError, json, readJson } from "./http";
import { requireSameOrigin, requireUser } from "./auth";
import { runAi, type AiRequest } from "./ai";
import { lushaPerson, recentLookups, type PersonQuery } from "./lusha";
import { deleteTab, getTab, getWorkspace, putTab, putWorkspace } from "./state";

export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    const reqId = crypto.randomUUID();
    const url = new URL(req.url);
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(req);
    const started = Date.now();
    let user = "-";
    try {
      requireSameOrigin(req);
      user = await requireUser(req, env);
      const res = await route(req, env, user, url);
      log(reqId, req, url, user, res.status, started);
      return res;
    } catch (e) {
      const res = errorResponse(e, reqId);
      log(reqId, req, url, user, res.status, started);
      return res;
    }
  },
} satisfies ExportedHandler<Env>;

async function route(req: Request, env: Env, user: string, url: URL): Promise<Response> {
  const p = url.pathname;
  const m = req.method;
  const tab = p.match(/^\/api\/tabs\/([^/]+)$/);

  if (p === "/api/me" && m === "GET") return json({ email: user, ai: !!env.ANTHROPIC_API_KEY, lusha: !!env.LUSHA_API_KEY });
  if (p === "/api/workspace" && m === "GET") return json(await getWorkspace(env, user));
  if (p === "/api/workspace" && m === "PUT") return json(await putWorkspace(env, user, await readJson(req, 600_000)));
  if (tab && m === "GET") return json(await getTab(env, user, tab[1]!));
  if (tab && m === "PUT") return json(await putTab(env, user, tab[1]!, await readJson(req, 300_000)));
  if (tab && m === "DELETE") return json(await deleteTab(env, user, tab[1]!));
  if (p === "/api/ai" && m === "POST") return json(await runAi(env, user, await readJson<AiRequest>(req, 200_000)));
  if (p === "/api/lusha/person" && m === "POST") return json(await lushaPerson(env, user, await readJson<PersonQuery>(req, 4_000)));
  if (p === "/api/lusha/recent" && m === "GET") return json({ items: await recentLookups(env, user) });
  throw new HttpError(404, "not_found", "No such endpoint.");
}

function log(reqId: string, req: Request, url: URL, user: string, status: number, started: number) {
  // Structured, no bodies (PII stays out of logs).
  console.log(JSON.stringify({ reqId, method: req.method, path: url.pathname, user, status, ms: Date.now() - started }));
}
