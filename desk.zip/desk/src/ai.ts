import type { Env } from "./env";
import { HttpError } from "./http";
import { consume, refund } from "./quota";

const SYSTEM = "You are a precise assistant for a UK white-collar recruitment consultant. British spelling. Plain text, no markdown headings or bold. Never invent people, contact details, employers, figures or dates.";
const MAX_PROMPT_CHARS = 150_000;

export interface AiRequest { prompt: string; json?: boolean }

export async function runAi(env: Env, user: string, body: AiRequest): Promise<{ text?: string; data?: unknown }> {
  if (typeof body?.prompt !== "string" || !body.prompt.trim()) throw new HttpError(400, "bad_request", "prompt is required.");
  if (body.prompt.length > MAX_PROMPT_CHARS) throw new HttpError(413, "too_large", "Input too long. Trim the pasted text.");
  if (!env.ANTHROPIC_API_KEY) throw new HttpError(503, "ai_not_configured", "ANTHROPIC_API_KEY secret is not set.");

  await consume(env, user, "ai", Number(env.AI_DAILY_CAP) || 300);
  const prompt = body.json
    ? body.prompt + "\n\nRespond with a single JSON value only. No prose, no code fences."
    : body.prompt;

  let res: Response;
  try {
    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: env.AI_MODEL, max_tokens: 4096, system: SYSTEM, messages: [{ role: "user", content: prompt }] }),
      signal: AbortSignal.timeout(110_000),
    });
  } catch (e) {
    await refund(env, user, "ai");
    throw new HttpError(504, "ai_timeout", "The AI didn’t respond in time. Try again.");
  }
  if (!res.ok) {
    await refund(env, user, "ai");
    const detail = (await res.text()).slice(0, 500);
    console.error(JSON.stringify({ level: "warn", upstream: "anthropic", status: res.status, detail }));
    if (res.status === 429 || res.status === 529) throw new HttpError(429, "rate_limited", "AI is busy. Wait a minute and try again.");
    throw new HttpError(502, "ai_upstream", `AI request failed (${res.status}).`);
  }
  const out = (await res.json()) as { content?: { type: string; text?: string }[]; stop_reason?: string };
  const text = (out.content ?? []).filter((b) => b.type === "text").map((b) => b.text ?? "").join("\n").trim();
  if (!body.json) return { text: out.stop_reason === "max_tokens" ? text + "\n\n[Output cut short. Narrow the request.]" : text };

  const cleaned = text.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "").trim();
  try {
    return { data: JSON.parse(cleaned) };
  } catch {
    throw new HttpError(502, "invalid_json", "The AI returned malformed data. Generate again.");
  }
}
