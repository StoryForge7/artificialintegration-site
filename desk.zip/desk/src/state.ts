import type { Env } from "./env";
import { HttpError } from "./http";

const MAX_WS = 512_000;
const MAX_TAB = 256_000;
const TAB_ID = /^[a-z0-9]{6,32}$/;

export async function getWorkspace(env: Env, user: string) {
  const row = await env.DB.prepare(`SELECT json, version, updated_at FROM workspace WHERE user_email = ?1`).bind(user).first<{ json: string; version: number; updated_at: number }>();
  return row ? { version: row.version, data: JSON.parse(row.json), updatedAt: row.updated_at } : { version: 0, data: null, updatedAt: 0 };
}

/** Optimistic concurrency: write only if the client saw the latest version. */
export async function putWorkspace(env: Env, user: string, body: { version: number; data: unknown }) {
  if (typeof body?.version !== "number" || body.data === null || typeof body.data !== "object") throw new HttpError(400, "bad_request", "version and data required.");
  const json = JSON.stringify(body.data);
  if (json.length > MAX_WS) throw new HttpError(413, "too_large", "Workspace too large. Close finished workflows.");
  const now = Date.now();
  if (body.version === 0) {
    const r = await env.DB.prepare(`INSERT INTO workspace (user_email, json, version, updated_at) VALUES (?1, ?2, 1, ?3) ON CONFLICT (user_email) DO NOTHING`).bind(user, json, now).run();
    if (r.meta.changes === 1) return { version: 1 };
  } else {
    const r = await env.DB.prepare(`UPDATE workspace SET json = ?1, version = version + 1, updated_at = ?2 WHERE user_email = ?3 AND version = ?4`).bind(json, now, user, body.version).run();
    if (r.meta.changes === 1) return { version: body.version + 1 };
  }
  const current = await getWorkspace(env, user);
  throw new HttpError(409, "conflict", "Changed on another device.", { current });
}

export async function getTab(env: Env, user: string, id: string) {
  if (!TAB_ID.test(id)) throw new HttpError(400, "bad_request", "Bad tab id.");
  const row = await env.DB.prepare(`SELECT json FROM tab_state WHERE user_email = ?1 AND tab_id = ?2`).bind(user, id).first<{ json: string }>();
  return { data: row ? JSON.parse(row.json) : null };
}

export async function putTab(env: Env, user: string, id: string, data: unknown) {
  if (!TAB_ID.test(id)) throw new HttpError(400, "bad_request", "Bad tab id.");
  const json = JSON.stringify(data ?? null);
  if (json.length > MAX_TAB) throw new HttpError(413, "too_large", "Tab content too large.");
  await env.DB.prepare(`INSERT INTO tab_state (user_email, tab_id, json, updated_at) VALUES (?1, ?2, ?3, ?4)
    ON CONFLICT (user_email, tab_id) DO UPDATE SET json = excluded.json, updated_at = excluded.updated_at`).bind(user, id, json, Date.now()).run();
  return { ok: true };
}

export async function deleteTab(env: Env, user: string, id: string) {
  if (!TAB_ID.test(id)) throw new HttpError(400, "bad_request", "Bad tab id.");
  await env.DB.prepare(`DELETE FROM tab_state WHERE user_email = ?1 AND tab_id = ?2`).bind(user, id).run();
  return { ok: true };
}
