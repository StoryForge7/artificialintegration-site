# Desk

Recruitment workflow desk on Cloudflare Workers + D1. Static UI in `public/`, API in `src/`.

## Deploy (once)

```bash
npm install
npx wrangler login
npx wrangler d1 create desk          # paste database_id into wrangler.jsonc
npm run db:migrate:remote
```

1. **Domain.** Add your domain to Cloudflare, then uncomment `routes` in `wrangler.jsonc` (e.g. `desk.yourdomain.com`).
2. **Access (login).** Zero Trust → Access → Applications → Add → Self-hosted.
   - Domain: `desk.yourdomain.com`
   - Policy: Allow → Emails → your email(s)
   - Copy the **Application Audience (AUD) tag** → `ACCESS_AUD`
   - Zero Trust → Settings → **Team domain** → `ACCESS_TEAM_DOMAIN` (e.g. `yourteam.cloudflareaccess.com`)
3. **Secrets.**
   ```bash
   npx wrangler secret put ANTHROPIC_API_KEY
   npx wrangler secret put LUSHA_API_KEY      # optional; Lusha tab disables itself without it
   ```
4. `npm run deploy`

No domain yet? Set `"workers_dev": true`, deploy, then enable Cloudflare Access on the workers.dev hostname (Workers → desk → Settings → Domains & Routes) and use that Access app's AUD tag. Never run it without Access: the Worker refuses API calls without a valid Access token.

## Local dev

```bash
cp .dev.vars.example .dev.vars        # DEV_USER_EMAIL bypasses Access on localhost only
npm run db:migrate:local
npm run dev                            # http://localhost:8787
```

## Design

| Concern | How |
|---|---|
| Auth | Cloudflare Access at the edge + JWT re-verified in the Worker (RS256, aud, iss, exp, key rotation) |
| CSRF | Mutations require same `Origin` + `X-Desk: 1` header |
| Secrets | Anthropic/Lusha keys are Worker secrets; never reach the browser |
| Concurrency | Workspace has a version; stale writes get 409 + current copy (phone vs desktop) |
| Cost control | Daily caps per user (`AI_DAILY_CAP`, `LUSHA_DAILY_CAP`); refunded when the call fails or Lusha doesn't charge |
| Lusha | Results cached 30 days per query (no double spend); every lookup stored → Motherboard |
| Audit | `audit` table: every Lusha call |
| Logs | Structured JSON per request, no bodies/PII. `npx wrangler tail` |
| Headers | CSP, nosniff, HSTS, frame-ancestors none (`public/_headers`) |
| Backups | D1 Time Travel: `npx wrangler d1 time-travel info desk`; export: `npx wrangler d1 export desk --remote --output backup.sql` |

## API

| Method | Path | Notes |
|---|---|---|
| GET | `/api/me` | email, which integrations are configured |
| GET/PUT | `/api/workspace` | `{version, data}`; 409 on conflict |
| GET/PUT/DELETE | `/api/tabs/:id` | per-tab inputs/outputs |
| POST | `/api/ai` | `{prompt, json?}` → `{text}` or `{data}` |
| POST | `/api/lusha/person` | `linkedinUrl` \| `email` \| `firstName`+`lastName`+(`companyName`\|`companyDomain`) |
| GET | `/api/lusha/recent` | last 100 lookups |

## Not built yet
- Google Sheets sync (Motherboard ↔ Motherload)
- CV → branded PDF
- Devyce call ingest (pending API access)
- Team accounts (data is already keyed per user email)

Before real candidate or client data goes in: employer sign-off, a lawful basis and a retention policy (UK GDPR).
